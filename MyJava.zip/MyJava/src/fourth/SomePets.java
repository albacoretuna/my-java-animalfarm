package fourth;

public class SomePets {
    
    public static void main(String[ ] args) {
        //  Creating a few Pet objects
        Pet a, b, c;
        a = new Pet("Felix", "cat", 5);
        b = new Pet("Jack", "dog", 1);
        c = new Pet();
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }
    
}

