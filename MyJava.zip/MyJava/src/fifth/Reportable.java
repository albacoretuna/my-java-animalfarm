package fifth;

public interface Reportable {
    
    public void report();
    
}

