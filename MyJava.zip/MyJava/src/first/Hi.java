package first;

import javax.swing.*;

public class Hi {
    
    public static void main(String[ ] a) {
        JOptionPane.showMessageDialog(null, "Hello again...");
    }
    
}

